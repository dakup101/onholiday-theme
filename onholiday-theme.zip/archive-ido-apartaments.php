<?php get_header(); ?>
<?php get_template_part(THEME_CMP, "apartaments") ?>
<?php get_footer(); ?>
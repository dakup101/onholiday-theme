import searchForm from "../class_Searchform";

export default function initSearchForm(){
    const form = new searchForm(".search-form");
}
<div class="mobile-nav">
    <div class="mobile-nav-inner">
        <a href="/" class="mobile-nav-item">
            <figure class="mobile-nav-icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                    <path
                        d="M20 7.093v-5.093h-3v2.093l3 3zm4 5.907l-12-12-12 12h3v10h7v-5h4v5h7v-10h3zm-5 8h-3v-5h-8v5h-3v-10.26l7-6.912 7 6.99v10.182z" />
                </svg>
            </figure>
            <span class="mobile-nav-desc">
                Home
            </span>
        </a>
        <a href="tel:+48572739208" class="mobile-nav-item">
            <figure class="mobile-nav-icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                    <path
                        d="M6.176 1.322l2.844-1.322 4.041 7.89-2.724 1.341c-.538 1.259 2.159 6.289 3.297 6.372.09-.058 2.671-1.328 2.671-1.328l4.11 7.932s-2.764 1.354-2.854 1.396c-7.862 3.591-19.103-18.258-11.385-22.281zm1.929 1.274l-1.023.504c-5.294 2.762 4.177 21.185 9.648 18.686l.971-.474-2.271-4.383-1.026.5c-3.163 1.547-8.262-8.219-5.055-9.938l1.007-.497-2.251-4.398z" />
                </svg>
            </figure>
            <span class="mobile-nav-desc">
                Zadzwoń
            </span>
        </a>
        <a href="/apartamenty" class="mobile-nav-item">
            <figure class="mobile-nav-icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                    <path
                        d="M23.809 21.646l-6.205-6.205c1.167-1.605 1.857-3.579 1.857-5.711 0-5.365-4.365-9.73-9.731-9.73-5.365 0-9.73 4.365-9.73 9.73 0 5.366 4.365 9.73 9.73 9.73 2.034 0 3.923-.627 5.487-1.698l6.238 6.238 2.354-2.354zm-20.955-11.916c0-3.792 3.085-6.877 6.877-6.877s6.877 3.085 6.877 6.877-3.085 6.877-6.877 6.877c-3.793 0-6.877-3.085-6.877-6.877z" />
                </svg>
            </figure>
            <span class="mobile-nav-desc">
                Oferta
            </span>
        </a>
        <button class="mobile-nav-item mobile-menu-trigger">
            <figure class="mobile-nav-icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                    <path d="M24 6h-24v-4h24v4zm0 4h-24v4h24v-4zm0 8h-24v4h24v-4z" />
                </svg>
            </figure>
            <span class="mobile-nav-desc">
                Menu
            </span>
        </button>
        <div class="mobile-nav-menu">
            <?php get_template_part(THEME_CMP, "header-mobile-nav") ?>

        </div>

    </div>


</div>
<div class="mobile-nav-overlay"></div>
<header class="header">
    <section class="container header-content">
        <a href="<?php echo get_home_url(); ?>" class="header-logo">
            <img src="<?php echo THEME_IMG . 'onholiday-logo.png'; ?>" alt="OnHoliday" class="header-logo-img" loading="lazy">
        </a>
        <div class="header-content-right">
            <?php echo get_template_part(THEME_CMP, "header-nav"); ?>

            <!-- <?php
                    echo get_template_part(THEME_CMP_CMN, "select", array(
                        "name" => "languageSwitcher",
                        "id" => "languageSwitcher",
                        "with_icon" => true,
                        "icon" => file_get_contents(THEME_IMG . '/icon/planet.svg'),
                        "options" => array(
                            "PL" => "PL",
                            "DE" => "DE",
                        ),
                        "class" => "header-nav-language",
                    ));
                    ?> -->

            <?php get_template_part(THEME_CMP_CMN, "btn", array(
                "link" => "/apartamenty/",
                "text" => "Rezerwuj",
                "class" => "header-nav-btn btn-content",
                "type" => "accent",
            )) ?>

        </div>
    </section>
</header>
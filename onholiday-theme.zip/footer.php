</main>
<?php get_template_part( THEME_CMP, "footer" ) ?>
</body>
<?php wp_footer() ?>

</html>
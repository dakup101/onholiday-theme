</main>
<?php get_template_part(THEME_CMP, "footer") ?>
<?php get_template_part(THEME_CMP, "header-mobile") ?>

</body>
<?php wp_footer() ?>

</html>
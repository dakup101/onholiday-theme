<?php
get_header();
get_template_part(THEME_CMP, "apartaments-single");
get_footer();

<?php get_header(); ?>
<?php get_template_part(THEME_CMP, "apartaments-single") ?>
<?php get_footer(); ?>
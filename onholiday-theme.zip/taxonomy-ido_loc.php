<?php get_header(); ?>
<?php get_template_part(THEME_CMP, "apartaments-with-loc") ?>
<?php get_footer(); ?>
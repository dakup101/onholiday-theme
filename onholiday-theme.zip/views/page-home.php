<?php // Template Name: Strona Główna 
?>

<?php get_header(); ?>
<?php
// Hero
$hero = (array) get_field("hero");
$is_slider = count($hero) > 1 ? true : false;
get_template_part(THEME_CMP, "hero", array(
    "is_slider" => $is_slider,
    "content" => $hero,
));
// Search Form
get_template_part(THEME_CMP, "search-form");
?>
<section class="container about-kolobrzeg">
    <?php get_template_part(THEME_CMP_CMN, "text-title", array(
        "title" => "Polecane apartamenty do wynajęcia",
        "subtitle" => null,
        "class" => "font-alt"
    )) ?>
    <p class="text-center">Proponujemy Wam kilkanaście prestiżowych<br>apartamentów w najlepszych lokalizacjach.</p>
    <div class="apartament-list addons">
        <?php $kolobrzeg_items = new WP_Query(array(
            "post_type" => "ido-apartaments",
            "status" => "publish",
            "orderby" => "rand",
            "posts_per_page" => 10,
            "tax_query" => array(
                "relation" => "AND",
                "operator" => "IN",
                array(
                    'taxonomy' => 'ido_category',
                    'field' => 'slug',
                    'terms' =>  "kolobrzeg",
                )
            )
        ));

        if ($kolobrzeg_items->have_posts()) : ?>
            <div class="offer-slider-wrapper">
                <div class="offer-slider">
                    <div class="swiper-wrapper">
                        <?php while ($kolobrzeg_items->have_posts()) : $kolobrzeg_items->the_post(); ?>
                            <div class="swiper-slide">
                                <article class="apartament-list-item">
                                    <a href="<?php echo get_the_permalink() ?>" class="apartament-list-item-inner">
                                        <div class="apartament-list-item-name">
                                            <?php echo get_the_title() ?>
                                        </div>
                                        <span class="apartament-list-item-link">
                                            Sprawdź szczegóły
                                        </span>
                                    </a>
                                    <figure class="apartament-list-item-bg">
                                        <img src="<?php echo get_field("media")[0]["url"] ?>" alt="<?php echo get_the_title()  ?>" loading="lazy">
                                        <div class="overlay"></div>

                                    </figure>
                                </article>
                            </div>
                        <?php endwhile;
                        wp_reset_query(); ?>
                    </div>

                </div>
                <div class="offer-slider-nav">
                    <div class="swiper-button-prev offer-slider-button-prev"></div>
                    <div class="swiper-button-next offer-slider-button-next">
                    </div>
                </div>
            </div>


        <?php endif; ?>
    </div>
    <div class="home-cards">
        <div class="home-cards-column">
            <?php get_template_part(THEME_CMP, "info-cards", get_field("cards")) ?>
            <form action="/apartamenty/" method="POST">
                <input type="hidden" name="searchLocation" value="kolobrzeg">
                <?php get_template_part(THEME_CMP_CMN, "btn", array(
                    "link" => null,
                    "text" => "Apartamenty w Kołobrzegu",
                    "class" => "search-form-action btn-content",
                    "type" => "accent",
                )) ?>
            </form>
        </div>
        <div class="home-cards-column">
            <?php get_template_part(THEME_CMP, "info-cards", get_field("cards_extra")) ?>

            <form action="/apartamenty/" method="POST">
                <input type="hidden" name="searchLocation" value="swieradow-zdroj">
                <?php get_template_part(THEME_CMP_CMN, "btn", array(
                    "link" => null,
                    "text" => "Apartamenty w Świeradowie-Zdroju",
                    "class" => "search-form-action btn-content",
                    "type" => "accent",
                )) ?>
            </form>
        </div>
    </div>
</section>
<?php get_template_part(THEME_CMP, "icons-row") ?>
<?php get_template_part(THEME_CMP, "cta", get_field("cta")) ?>
<?php get_template_part(THEME_CMP, "info-right", get_field("info-right")) ?>
<?php get_template_part(THEME_CMP, "info-left", get_field("info-left")) ?>
<?php get_template_part(THEME_CMP, "blog-grid", get_field("blog_grid_fields", "options")) ?>
<div class="container summary-wrapper">
    <?php get_template_part(THEME_CMP, "summary", get_field("summary")) ?>
</div>
<?php get_footer(); ?>